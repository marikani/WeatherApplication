var initialState = {
  weatherData: []
}

const WeatherReducer = (state = initialState, action) => {
  switch (action.type) {
    case "GET_WEATHER_DATA":
      state = {
        weatherData: action.payload
      }
      break;
    default:
      break;
  }
  return state;
}

export default WeatherReducer;