import { createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import WeatherReducer from '../Reducer/WeatherReducer';

const Store = createStore(WeatherReducer, applyMiddleware(thunk));

export default Store;