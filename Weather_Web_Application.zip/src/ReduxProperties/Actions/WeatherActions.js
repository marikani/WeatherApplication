export function getWeatherData(val) {
  return dispatch => {
    let obj = {
      "date": val
    }
    fetch("http://interview.com360degree.com/api/getWeather",
      {
        method: 'POST',
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify(obj)
      })
      .then(response => response.json())
      .then(data => {
        dispatch({
          type: "GET_WEATHER_DATA",
          payload: data.data
        })
      })
      .catch(error => console.error(error))
  }
}