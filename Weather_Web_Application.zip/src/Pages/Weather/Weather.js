import React from 'react';
import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";
import './Weather.css';
import { connect } from 'react-redux';
import { getWeatherData } from '../../ReduxProperties/Actions/WeatherActions'

class Weather extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      startDate: new Date(),
      selectedDate: new Date(),
    }
  }

  handleChange = date => {
    this.setState({
      selectedDate: date
    }, () => {
      this.props.getData(this.state.selectedDate);
    });
  };

  showForecast(data) {
    return data.map((val, i) => {
      return (
        <div className="dailyDiv" key={i}>
          <p style={{ color: '#fff' }}>{val.day}</p>
          {/* <img src={require('')} style={{ width: '50px', height: '50px' }} /> */}
          <h4 style={{ color: '#fff' }}>{val.skycodeday} &#8451;</h4>
        </div>
      )
    })

  }

  componentDidMount() {
    this.props.getData(this.state.selectedDate);
  }

  showValues(val) {
    return val.map((data, i) => {
      return (
        <div className="SubDiv" key={i}>
          <DatePicker
            selected={this.state.selectedDate}
            onChange={this.handleChange}
            style={{ margin: 10 }}
          />
          <div className="firstDiv">
            <div style={{ flex: 0.5, }}>
              <div style={{ margin: 10 }}>
                <h1 style={{ color: '#fff', margin: 0 }}>{data.current.skytext}</h1>
                <h3 style={{ color: '#fff', margin: 0 }}>{data.current.temperature} &#8451;</h3>
                <div style={{ paddingTop: 5 }}>
                  <p className="detailText">Feels like <span>{data.current.feelslike} &#8451;</span></p>
                  <p className="detailText">Humidity <span>{data.current.humidity} &#8451;</span></p>
                  <p className="detailText">Windspeed <span>{data.current.windspeed}</span></p>
                </div>
              </div>
            </div>
            <div style={{ flex: 0.5, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
              <img src={data.current.imageUrl} style={{ width: '150px', height: '150px' }} />
            </div>
          </div>
          <div style={{ display: 'flex', flex: 0.5 }}>
            {
              this.showForecast(data.forecast)
            }
          </div>
        </div>
      )
    })
  }

  render() {
    return (
      <div className="App">
        {
          this.props.weatherData.length > 0 ?
            this.showValues(this.props.weatherData)
            :
            <h1 style={{ color: '#fff' }}>Loading...</h1>
        }
      </div >
    )
  }
}

function mapStateToProps(state) {
  console.log(state.weatherData);
  return {
    weatherData: state.weatherData
  };
}

function mapDispatchToProps(dispatch) {
  return {
    getData: (val) => dispatch(getWeatherData(val))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Weather)