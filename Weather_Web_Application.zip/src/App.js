import React from 'react';
import Weather from './Pages/Weather/Weather';
import { Provider } from 'react-redux';
import store from '../src/ReduxProperties/Store/Store';

export default class App extends React.Component {

  render() {
    return (
      <Provider store={store}>
        <Weather />
      </Provider>
    )
  }
}